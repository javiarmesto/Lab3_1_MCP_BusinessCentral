# Code Citations

## License: unknown
https://github.com/MicrosoftDocs/dynamics365smb-devitpro-pb/tree/c72a2326b8ebbc906833229b9c28524528e09f26/dev-itpro/api-reference/v2.0/api/dynamics_customer_create.md

```
"Adatum Corporation",
        "type": "Company",
        "addressLine1": "192 Market Square",
        "addressLine2": "",
        "city": "Atlanta",
        "state": "GA",
        "country": "US",
        "
```


## License: unknown
https://github.com/MicrosoftDocs/dynamics365smb-devitpro-pb/tree/c72a2326b8ebbc906833229b9c28524528e09f26/dev-itpro/api-reference/v2.0/api/dynamics_customer_update.md

```
Company",
        "addressLine1": "192 Market Square",
        "addressLine2": "",
        "city": "Atlanta",
        "state": "GA",
        "country": "US",
        "postalCode": "31772",
        "phoneNumber"
```

